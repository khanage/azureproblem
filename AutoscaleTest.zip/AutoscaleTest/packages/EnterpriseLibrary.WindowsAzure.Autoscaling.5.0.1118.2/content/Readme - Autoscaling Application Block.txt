MICROSOFT ENTERPRISE LIBRARY 5.0 INTEGRATION PACK FOR WINDOWS AZURE 
AUTOSCALING APPLICATION BLOCK ("WASABI")
5.0.1118.2

Summary: The Autoscaling Application Block provides reusable and testable components to add or manage autoscaling capabilities for Windows Azure hosted services and applications.

The most up-to-date version of the release notes and known issues is available online:
http://entlib.codeplex.com/wikipage?title=ELAzureReleaseNotes


Microsoft patterns & practices
http://msdn.microsoft.com/practices
